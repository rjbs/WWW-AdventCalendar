package MyApp::Controller::Books;

use strict;
use warnings;
use Data::Dump;
use base 'Catalyst::Controller';

=head1 NAME

MyApp::Controller::Books - Catalyst Controller

=head1 DESCRIPTION

Catalyst Controller.

=head1 METHODS

=cut


=head2 index 

=cut

sub index :Path :Args(0) {
    my ( $self, $c ) = @_;

    $c->response->body('Matched MyApp::Controller::Books in Books.');
}



=head2 list

Fetch all book objects and pass to books/list.tt2 in stash to be displayed

=cut
 
sub list : Local {
    # Retrieve the usual Perl OO '$self' for this object. $c is the Catalyst
    # 'Context' that's used to 'glue together' the various components
    # that make up the application
    my ($self, $c) = @_;

    # Retrieve all of the book records as book model objects and store in the
    # stash where they can be accessed by the TT template
    $c->stash->{books} = [$c->model('DB::Books')->all];
    
    # Set the TT template to use.  You will almost always want to do this
    # in your action methods (action methods respond to user input in
    # your controllers).
    $c->stash->{template} = 'books/list.tt2';
}



=head2 url_create

Create a book with the supplied title, rating, and author

=cut

sub url_create : Local {
    # In addition to self & context, get the title, rating, & 
    # author_id args from the URL.  Note that Catalyst automatically 
    # puts extra information after the "/<controller_name>/<action_name/" 
    # into @_
    my ($self, $c, $title, $rating, $author_id) = @_;

    # Call create() on the book model object. Pass the table 
    # columns/field values we want to set as hash values
    my $book = $c->model('DB::Books')->create({
            title  => $title,
            rating => $rating
        });
    
    # Add a record to the join table for this book, mapping to 
    # appropriate author
    $book->add_to_book_authors({author_id => $author_id});
    # Note: Above is a shortcut for this:
    # $book->create_related('book_authors', {author_id => $author_id});
    
    # Assign the Book object to the stash for display in the view
    $c->stash->{book} = $book;

    # This is a hack to disable XSUB processing in Data::Dumper
    # (it's used in the view).  This is a work-around for a bug in
    # the interaction of some versions or Perl, Data::Dumper & DBIC.
    # You won't need this if you aren't using Data::Dumper (or if
    # you are running DBIC 0.06001 or greater), but adding it doesn't 
    # hurt anything either.
    $Data::Dumper::Useperl = 1;

    # Set the TT template to use
    $c->stash->{template} = 'books/create_done.tt2';
}



=head2 form_create

Display form to collect information for book to create

=cut

sub form_create : Local {
    my ($self, $c) = @_;

    # Set the TT template to use
    $c->stash->{template} = 'books/form_create.tt2';
}



=head2 form_create_do

Take information from form and add to database

=cut

sub form_create_do : Local {
    my ($self, $c) = @_;

    # Retrieve the values from the form
    my $title     = $c->request->params->{title}     || 'N/A';
    my $rating    = $c->request->params->{rating}    || 'N/A';
    my $author_id = $c->request->params->{author_id} || '1';

    # Create the book
    my $book = $c->model('DB::Books')->create({
            title   => $title,
            rating  => $rating,
        });
    # Handle relationship with author
    $book->add_to_book_authors({author_id => $author_id});

    # Store new model object in stash
    $c->stash->{book} = $book;

    # Avoid Data::Dumper issue mentioned earlier
    # You can probably omit this    
    $Data::Dumper::Useperl = 1;

    # Set the TT template to use
    $c->stash->{template} = 'books/create_done.tt2';
}

sub create_do : Local {
    my ($self, $c) = @_;
    
    # creating default values in object that will be serialized
    my $ret =
    {
        status => 'Unsuccessful',
        error => {Unknown => ''},
        data => {}
    };

    # Retrieve the values from the form
    my $title     = $c->request->params->{title};
    my $rating    = $c->request->params->{rating};
    my $author_id = $c->request->params->{author_id};
    
    $c->log->info("title: $title");
    $c->log->info("rating: $rating");
    $c->log->info("author_id: $author_id");
    
    # Validate input first
    if(!defined($title) || $title =~ m/[^a-zA-Z0-9 \-\.\/\,]/)
    {
        $c->log->info("title not defined or matches invalid characters rejecting");
        delete($ret->{error}->{'Unknown'}) if defined($ret->{error}->{'Unknown'});
        $ret->{error}->{"Invalid Characters"} = 'Title contains unsupported characters or is not defined';
    }
    elsif(!defined($rating) || $rating =~ m/[^1-5]/)
    {
        $c->log->info("rating not defined or matches invalid characters rejecting");
        delete($ret->{error}->{'Unknown'}) if defined($ret->{error}->{'Unknown'});
        $ret->{error}->{"Invalid Characters"} = 'Rating contains unsupported characters must be value of 1-5 or is not defined';
    }
    elsif(!defined($author_id) || $author_id =~ m/[^0-9]/ || $author_id == 0)
    {
        $c->log->info("author_id not defined or matches invalid characters rejecting");
        delete($ret->{error}->{'Unknown'}) if defined($ret->{error}->{'Unknown'});
        $ret->{error}->{"Invalid Characters"} = 'Author_ID contains unsupported characters must be valid id or is not defined';
    }
    else
    {
        $c->log->info("No invalid characters or undefined values in the input");
        
        # Create the book
        my $book = $c->model('DB::Books')->create({
                title   => $title,
                rating  => $rating,
            });
        
        # Handle relationship with author
        $book->add_to_book_authors({author_id => $author_id});
        
        $c->log->info("Created book_id: ",$book->id);
        
        my $authors = [];
        foreach my $author ($book->authors)
        {
            $c->log->info("last name: ", $author->last_name);
            push(@$authors, $author->last_name);
        }
        
        delete($ret->{error}->{'Unknown'}) if defined($ret->{error}->{'Unknown'});
        $ret->{status} = 'Successful';
        
        $ret->{data} =
        {
            book_id => $book->id,
            title => $book->title,
            rating => $book->rating,
            authors => $authors,
            link => $c->uri_for('/books/delete/').$book->id
        };
    }
    
    # Putting our return data into the json stash to get serialized into json
    $c->stash->{json} = $ret;
    
    $c->forward('MyApp::View::JSON');
}


=head2 delete 

Delete a book
    
=cut

sub delete : Local {
    # $id = primary key of book to delete
    my ($self, $c, $id) = @_;

    # Search for the book and then delete it
    $c->model('DB::Books')->search({id => $id})->delete_all;

    # Redirect the user back to the list page with status msg as an arg
    $c->response->redirect($c->uri_for('/books/list', 
        {status_msg => "Book deleted."}));
}



=head1 AUTHOR

A clever guy

=head1 LICENSE

This library is free software, you can redistribute it and/or modify
it under the same terms as Perl itself.

=cut

1;
