//Creates MochiKit logging pane. Remove true if you want it popped out in its own window
createLoggingPane(true);

var message = getElement('message');
var error = getElement('error');
var list_body = getElement('list_body');
var title = getElement('title');
var rating = getElement('rating');
var author_id = getElement('author_id');
var add_book = getElement('add_book');

//function to update error or message spans
var update_user = function (type, txt)
{
    var p_txt;
    
    if(type == 'message')
    {
        p_txt = P({'style':'display:none'},'Status: '+txt);
        replaceChildNodes(message, [p_txt]);
    }
    else if (type == 'error')
    {
        p_txt = P({'style':'display:none'},'Error: '+txt);
        replaceChildNodes(error, [p_txt]);
    }
    
    appear(p_txt,{'speed':0.1});
}

//Creating a partial for updating the message and error spans for example purposes
var u_message = partial(update_user,'message');
var u_error = partial(update_user,'error');

connect
(
    add_book,
    'onclick',
    function ()
    {
        log("I have been clicked");
        log("Title: ", title.value);
        log("Rating: ", rating.value);
        log("Author_ID: ", author_id.value);
        
        //Creating our params object to hold our arguments that we will be posting
        var params =
        {
            title: title.value,
            rating: rating.value,
            author_id: author_id.value
        };
        
        //Calling MochiKits doXHR which makes XMLHttpRequests painless
        var d = doXHR
        (
            '/books/create_do',
            {
                'method': 'POST',
                'sendContent': queryString(params),
                'headers': {'Content-Type':'application/x-www-form-urlencoded'}
            }
        );
        
        //Creating a callback on success to process our json response
        d.addCallback
        (
            function (req)
            {
                //eval'ing and assigning our returned json data to resp variable
                var resp = evalJSONRequest(req);
                
                //logging to firebug as an example comment out if not installed
                console.log(resp);
                
                //Checking to see we have a successful response in our returned data
                if(resp.status == 'Successful')
                {
                    log('Response has status of successful');
                    
                    //calling our partial function
                    u_message(resp.status);
                    
                    //creating dom elements. first arg pass is named args for attributes
                    //second arg passed is data inside element. can be string or array of more
                    //elements consult mochikit docs for full details
                    var td_title = TD(null, resp.data.title);
                    var td_rating = TD(null, resp.data.rating);
                    var td_authors = TD(null, '(' + resp.data.authors.length + ') ' + resp.data.authors.join(', '));
                    var a_link = A({'href':resp.data.link}, ['Delete']);
                    var td_links = TD(null, [a_link]);
                    
                    //creating our tr which holds all of our previously created elements
                    var tr_book = TR
                    (
                        null,
                        [
                            td_title,
                            td_rating,
                            td_authors,
                            td_links
                        ]
                    );
                    
                    //you can log this to firebug and actually inspect the dom
                    //its like a hackish Data::Dump::dump() for JavaScript
                    console.log(tr_book);
                    
                    //Calling MochiKits appendChildNodes() to only the fly update the DOM
                    appendChildNodes(list_body, [tr_book]);
                }
                else
                {
                    log('Response has status of NON successful');
                    
                    //calling our partial function
                    u_message(resp.status);
                    
                    //getting error reason and txt and updating user
                    for (i in resp.error)
                    {
                        log('Error is:',i);
                        log('Reason is:',resp.error[i]);
                        u_error(i+': '+resp.error.i);
                    }
                }
            }
        )
    }
);